import React from "react";
import {
  VerticalTimeline,
  VerticalTimelineElement,
} from "react-vertical-timeline-component";
import "react-vertical-timeline-component/style.min.css";
import SchoolIcon from "@material-ui/icons/School";
import WorkIcon from "@material-ui/icons/Work";

function Experience() {
  return (
    <div className="experience">
      <VerticalTimeline lineColor="#3e497a">
      <VerticalTimelineElement
      className="vertical-timeline-element--education"
      date="2007 - 2016"
      iconStyle={{ background: "#3e497a", color: "#fff" }}
      icon={<SchoolIcon />}
    >
      <h3 className="vertical-timeline-element-title">
      CMS Matriculation Higher Secondary School , CBE  
      </h3>
      <p> Primary  School - A Grade </p>
    </VerticalTimelineElement>

        <VerticalTimelineElement
          className="vertical-timeline-element--education"
          date="2016 - 2019"
          iconStyle={{ background: "#3e497a", color: "#fff" }}
          icon={<SchoolIcon />}
        >
          <h3 className="vertical-timeline-element-title">
          CMS Matriculation Higher Secondary School , CBE  
          </h3>
          <p> Middle School - 92 % </p>
        </VerticalTimelineElement>
        <VerticalTimelineElement
          className="vertical-timeline-element--education"
          date="2019 - 2021"
          iconStyle={{ background: "#3e497a", color: "#fff" }}
          icon={<SchoolIcon />}
        >
          <h3 className="vertical-timeline-element-title">
          CMS Matriculation Higher Secondary School , CBE  
          </h3>
          <p> High School - 94 % </p>
        </VerticalTimelineElement>
        

        
        <VerticalTimelineElement
          className="vertical-timeline-element--education"
          date="2021 - 2025"
          iconStyle={{ background: "#3e497a", color: "#fff" }}
          icon={<SchoolIcon />}
        >
          <h3 className="vertical-timeline-element-title">
            Sri Krishna College of Engineering and Teachnology, Coimbatore 
          </h3>

          <h4 className="vertical-timeline-element-subtitle">
            Bachelor's Degree
          </h4>

          <p> Electrical and Electronics Engineering </p>
        </VerticalTimelineElement>

        <VerticalTimelineElement
          className="vertical-timeline-element--work"
          date="2021 - present"
          iconStyle={{ background: "#e9d35b", color: "#fff" }}
          icon={<WorkIcon />}
        >
          <h3 className="vertical-timeline-element-title">
           Design Engineer  - Team Gandiva
          </h3>
          <h4 className="vertical-timeline-element-subtitle">
            SKCET , CBE
          </h4>
          <p>
            Building our own electric kart from scratch 
          </p>
        </VerticalTimelineElement>


      </VerticalTimeline>
    </div>
  );
}

export default Experience;
